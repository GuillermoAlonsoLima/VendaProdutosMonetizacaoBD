/* Util
 * Possui classes auxiliares
 */
package Util;
