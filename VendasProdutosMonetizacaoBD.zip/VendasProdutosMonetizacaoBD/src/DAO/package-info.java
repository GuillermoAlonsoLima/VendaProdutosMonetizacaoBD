/* DAO
 * Possui as classes responsáveis por executarem comandos no banco de dados.
 */
package DAO;
