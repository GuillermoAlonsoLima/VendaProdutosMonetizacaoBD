/* Verificar
 * Possui verificações de dados
 */
package Verificar;
