/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Menus;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @author 631510046
 */
@org.junit.runner.RunWith(org.junit.runners.Suite.class)
@org.junit.runners.Suite.SuiteClasses({ProdutoMenuTest.class, VendaMenuTest.class, MonetizacaoMenuTest.class, RelatoriosMenuTest.class, ClienteMenuTest.class, ContaMenuTest.class})
public class MenusSuite {

    @org.junit.BeforeClass
    public static void setUpClass() throws Exception {
    }

    @org.junit.AfterClass
    public static void tearDownClass() throws Exception {
    }

    @org.junit.Before
    public void setUp() throws Exception {
    }

    @org.junit.After
    public void tearDown() throws Exception {
    }
    
}
