/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author 631510046
 */
public class RelatoriosDAOTest {
    
    public RelatoriosDAOTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of produtosVendidos method, of class RelatoriosDAO.
     */
    @org.junit.Test
    public void testProdutosVendidos() {
        System.out.println("produtosVendidos");
        RelatoriosDAO.produtosVendidos();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of comprasConta method, of class RelatoriosDAO.
     */
    @org.junit.Test
    public void testComprasConta() {
        System.out.println("comprasConta");
        String conta = "";
        RelatoriosDAO.comprasConta(conta);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of contaMaisCompra method, of class RelatoriosDAO.
     */
    @org.junit.Test
    public void testContaMaisCompra() {
        System.out.println("contaMaisCompra");
        RelatoriosDAO.contaMaisCompra();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of contaMaisMonetiza method, of class RelatoriosDAO.
     */
    @org.junit.Test
    public void testContaMaisMonetiza() {
        System.out.println("contaMaisMonetiza");
        RelatoriosDAO.contaMaisMonetiza();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
