/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author 631510046
 */
public class VendaDAOTest {
    
    public VendaDAOTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of cadastrar method, of class VendaDAO.
     */
    @org.junit.Test
    public void testCadastrar() {
        System.out.println("cadastrar");
        int conta = 0;
        VendaDAO.cadastrar(conta);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of cadastrarProdutos method, of class VendaDAO.
     */
    @org.junit.Test
    public void testCadastrarProdutos() {
        System.out.println("cadastrarProdutos");
        String produto = "";
        int qtd = 0;
        VendaDAO.cadastrarProdutos(produto, qtd, 1);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deletar method, of class VendaDAO.
     */
    @org.junit.Test
    public void testDeletar() {
        System.out.println("deletar");
        String coluna = "";
        String valor = "";
        VendaDAO.deletar(coluna, valor);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of atualizar method, of class VendaDAO.
     */
    @org.junit.Test
    public void testAtualizar() {
        System.out.println("atualizar");
        String coluna1 = "";
        String valor1 = "";
        String coluna2 = "";
        String valor2 = "";
        VendaDAO.atualizar(coluna1, valor1, coluna2, valor2);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of selecionar method, of class VendaDAO.
     */
    @org.junit.Test
    public void testSelecionar() {
        System.out.println("selecionar");
        String coluna = "";
        String valor = "";
        VendaDAO.selecionar(coluna, valor);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of selecionarTudo method, of class VendaDAO.
     */
    @org.junit.Test
    public void testSelecionarTudo() {
        System.out.println("selecionarTudo");
        VendaDAO.selecionarTudo();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of completarVenda method, of class VendaDAO.
     */
    @org.junit.Test
    public void testCompletarVenda() {
        System.out.println("completarVenda");
        VendaDAO.completarVenda();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
