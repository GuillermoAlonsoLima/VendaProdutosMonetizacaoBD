/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UI;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author 631510046
 */
public class ContaUITest {
    
    public ContaUITest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of cadastrar method, of class ContaUI.
     */
    @org.junit.Test
    public void testCadastrar() {
        System.out.println("cadastrar");
        ContaUI.cadastrar();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deletar method, of class ContaUI.
     */
    @org.junit.Test
    public void testDeletar() {
        System.out.println("deletar");
        ContaUI.deletar();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of atualizar method, of class ContaUI.
     */
    @org.junit.Test
    public void testAtualizar() {
        System.out.println("atualizar");
        ContaUI.atualizar();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of selecionar method, of class ContaUI.
     */
    @org.junit.Test
    public void testSelecionar() {
        System.out.println("selecionar");
        ContaUI.selecionar();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
