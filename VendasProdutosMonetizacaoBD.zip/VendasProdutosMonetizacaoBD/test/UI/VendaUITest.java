/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UI;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author 631510046
 */
public class VendaUITest {
    
    public VendaUITest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of cadastrar method, of class VendaUI.
     */
    @org.junit.Test
    public void testCadastrar() {
        System.out.println("cadastrar");
        VendaUI.cadastrar();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of cadastrarProduto method, of class VendaUI.
     */
    @org.junit.Test
    public void testCadastrarProduto() {
        System.out.println("cadastrarProduto");
        VendaUI.cadastrarProduto(1);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deletar method, of class VendaUI.
     */
    @org.junit.Test
    public void testDeletar() {
        System.out.println("deletar");
        VendaUI.deletar();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of atualizar method, of class VendaUI.
     */
    @org.junit.Test
    public void testAtualizar() {
        System.out.println("atualizar");
        VendaUI.atualizar();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of selecionar method, of class VendaUI.
     */
    @org.junit.Test
    public void testSelecionar() {
        System.out.println("selecionar");
        VendaUI.selecionar();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
